import csORF_finder
from csORF_finder import test_model

test_model('D:/csORF-finder_program/input_files/M.musculus/non-CDS/', 'D:/csORF-finder_program/output_files/',
           'mm_ncrna_test.txt', 'M.musculus', 'non-CDS')